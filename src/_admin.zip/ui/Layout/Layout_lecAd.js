import { Nav, Container, Row, Col } from "react-bootstrap";
import { Outlet, useNavigate } from "react-router-dom";

const navItems = [
    { label: "강의 등록", path: "/lectureRegister" },
    { label: "강의 목록", path: "/lectureList" },
];

export const LayoutStLec = () => {
    const navigate = useNavigate();

    return (
        <div
            style={{
                backgroundColor: "#f0f2f5",
                minHeight: "100vh",
                padding: "1.5rem",
            }}
        >
            <Container fluid="lg" style={{ maxWidth: "1200px" }}>
                <Row className="g-3">
                    {/* 왼쪽 사이드바 */}
                    <Col
                        xs={12}
                        md={3}
                        lg={2}
                        className="bg-dark text-white p-3 rounded shadow"
                        style={{ minHeight: "85vh", overflowY: "auto" }}
                    >
                        <Nav className="flex-column">
                            {navItems.map(({ label, path }) => (
                                <Nav.Link
                                    key={path}
                                    onClick={() => navigate(path)}
                                    className="text-white fw-semibold"
                                >
                                    {label}
                                </Nav.Link>
                            ))}
                        </Nav>
                    </Col>

                    {/* 오른쪽 콘텐츠 */}
                    <Col
                        xs={12}
                        md={9}
                        lg={10}
                        className="bg-white p-4 rounded shadow"
                        style={{ minHeight: "85vh", overflowY: "auto" }}
                    >
                        <Outlet />
                    </Col>
                </Row>
            </Container>
        </div>
    );
};
