import { Nav } from "react-bootstrap";
import { Outlet, useNavigate } from "react-router-dom";

const navItems = [
    { label: "구성원 관리 홈", path: "/sthm/ad" },
    { label: "구성원 등록", path: "/user/insert_user" },
    { label: "구성원 일괄등록", path: "/user/UserBatchReg" },
    { label: "구성원 리스트", path: "/user/UserList" },
    { label: "1:1 문의 관리", path: "/inquiry/admin" },
];

export const LayoutStCon = () => {
    const navigate = useNavigate();

    return (
        <div
            className="d-flex flex-column"
            style={{
                backgroundColor: "#f0f2f5",
                minHeight: "100vh",
                padding: "1.5rem",
            }}
        >
            <div
                className="d-flex flex-grow-1"
                style={{
                    maxWidth: "1200px",
                    margin: "0 auto",
                    width: "100%",
                    height: "100%",
                }}
            >
                {/* 사이드바 */}
                <div
                    className="bg-dark text-white p-3 rounded shadow"
                    style={{
                        width: "220px",
                        minHeight: "100%",
                        overflowY: "auto",
                        flexShrink: 0,
                    }}
                >
                    <Nav className="flex-column">
                        {navItems.map(({ label, path }) => (
                            <Nav.Link
                                key={path}
                                onClick={() => navigate(path)}
                                className="text-white fw-semibold"
                            >
                                {label}
                            </Nav.Link>
                        ))}
                    </Nav>
                </div>

                {/* 콘텐츠 */}
                <div
                    className="bg-white p-4 ms-3 rounded shadow flex-grow-1"
                    style={{
                        overflowY: "auto",
                        height: "100%",
                    }}
                >
                    <Outlet />
                </div>
            </div>
        </div>
    );
};
