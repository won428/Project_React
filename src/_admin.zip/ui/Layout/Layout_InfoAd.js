import { Nav } from "react-bootstrap";
import { Outlet, useNavigate } from "react-router-dom";

const navItems = [
    { label: "통합 정보 홈", path: "/infohome/ad" },
    { label: "단과대학 조회", path: "/collist" },
    { label: "단과대학 등록", path: "/colreg" },
    { label: "학과 조회", path: "/majorList" },
    { label: "학과 등록", path: "/majorReg" },
];

export const LayoutStInfo = () => {
    const navigate = useNavigate();

    return (
        <div
            className="d-flex flex-column"
            style={{
                backgroundColor: "#f0f2f5",
                minHeight: "100vh",
                padding: "1.5rem",
            }}
        >
            <div
                className="d-flex flex-grow-1"
                style={{
                    maxWidth: "1200px",
                    width: "100%",
                    margin: "0 auto",
                    height: "calc(100vh - 3rem)", // 헤더 등 고려한 실제 높이 확보
                }}
            >
                {/* 사이드바 */}
                <div
                    className="bg-dark text-white p-3 rounded shadow"
                    style={{
                        width: "220px",
                        overflowY: "auto",
                        height: "100%",
                        flexShrink: 0,
                    }}
                >
                    <Nav className="flex-column">
                        {navItems.map(({ label, path }) => (
                            <Nav.Link
                                key={path}
                                onClick={() => navigate(path)}
                                className="text-white fw-semibold"
                            >
                                {label}
                            </Nav.Link>
                        ))}
                    </Nav>
                </div>

                {/* 콘텐츠 */}
                <div
                    className="bg-white p-4 ms-3 rounded shadow flex-grow-1"
                    style={{
                        overflowY: "auto",
                        height: "100%",
                    }}
                >
                    <Outlet />
                </div>
            </div>
        </div>
    );
};
