


const API_HOST = "localhost";

const API_PORT = "9100";

export const API_BASE_URL = `http://${API_HOST}:${API_PORT}`