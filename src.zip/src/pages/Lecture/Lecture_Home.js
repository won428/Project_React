import Layout from "../../ui/Layout_lec";
function App() {
    return (
        <Layout>
            LHome
        </Layout>
    )
}
export default App;