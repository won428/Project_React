import Layout from "../../ui/Layout_lec";

function App() {
    return (
        <Layout>
            ToDoList
        </Layout>
    )
}
export default App;