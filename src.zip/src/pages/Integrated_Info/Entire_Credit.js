import Layout_Info from "../../ui/Layout_Info";


function App() {
    return (
        <Layout_Info>
            Entire_Credit
        </Layout_Info>
    )
}
export default App;