import Layout_Info from "../../ui/Layout_Info";

function App() {
    return (
        <>
            <Layout_Info>
                InfoHome
            </Layout_Info>
        </>
    )
}
export default App;