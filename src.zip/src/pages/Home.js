import { Col, Container, Row } from "react-bootstrap";


function App() {
    return (
        <Container className="mt-4">
            <Row>
                <Col>
                    Home

                </Col>
            </Row>
        </Container>
    )
}
export default App;