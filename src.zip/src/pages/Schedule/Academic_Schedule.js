import { Calendar, dataFnsLocalizer } from "react-big-calendar";
import { Container } from "react-bootstrap";


function App() {
    return (
        <Container className="mt-4">
            (가안) react-big-calendar dataFnsLocalizer 활용
            캘린더 형태 눌렀을 때 한 주형태의 캘린더 형태로 출력
            description 활용
            or 그냥 캘린더 형태만 description 삭제
        </Container>
    )
}
export default App;